﻿using Microsoft.AspNetCore.Identity;

namespace Day_4.Models
{
    public class ApplicationUser : IdentityUser
    {
        // Additional properties can go here
    }
}
